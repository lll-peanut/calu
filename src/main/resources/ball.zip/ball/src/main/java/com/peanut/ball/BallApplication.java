package com.peanut.ball;

import javax.swing.*;

/**
 * @author: peanut
 * @date: 2026/5/19
 * @version:1.0
 */
public class BallApplication {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GameFrame frame = new GameFrame();
            frame.setVisible(true);
        });
    }

}
