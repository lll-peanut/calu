package com.peanut.ball;
import java.awt.*;
/**
 * @author: peanut
 * @date: 2026/5/19
 * @version:1.0
 */
public class Ball {
    public double x, y;     // 圆心坐标
    public double vx, vy;   // 速度分量
    public int r;           // 半径
    public Color color;

    public Ball(double x, double y, double vx, double vy, int r, Color color) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.r = r;
        this.color = color;
    }
}