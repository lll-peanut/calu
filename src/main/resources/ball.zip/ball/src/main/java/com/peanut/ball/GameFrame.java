package com.peanut.ball;

import javax.swing.*;
import java.awt.*;

/**
 * @author: peanut
 * @date: 2026/5/19
 * @version:1.0
 */
public class GameFrame extends JFrame {

    private final JTextField ballCountField = new JTextField("10", 6);
    private final JButton startBtn = new JButton("开始/重开");
    private final JLabel timeLabel = new JLabel("时间：0.0 s");
    private final JLabel stateLabel = new JLabel("状态：未开始");

    private final GamePanel gamePanel = new GamePanel(timeLabel, stateLabel);

    public GameFrame() {
        super("弹球躲避游戏");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("小球数量："));
        top.add(ballCountField);
        top.add(startBtn);
        top.add(timeLabel);
        top.add(Box.createHorizontalStrut(10));
        top.add(stateLabel);

        startBtn.addActionListener(e -> {
            int n;
            try {
                n = Integer.parseInt(ballCountField.getText().trim());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "请输入合法整数", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (n < 1 || n > 300) {
                JOptionPane.showMessageDialog(this, "建议输入 1~300", "提示", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            gamePanel.startNewGame(n);
        });

        setLayout(new BorderLayout());
        add(top, BorderLayout.NORTH);
        add(gamePanel, BorderLayout.CENTER);

        setSize(900, 600);
        setLocationRelativeTo(null);
    }
}