package com.peanut.ball;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.*;

/**
 * @author: peanut
 * @date: 2026/5/19
 * @version:1.0
 */
public class GamePanel extends JPanel {

    // 鼠标方块大小
    private static final int MOUSE_BOX = 14;

    // 游戏更新周期（毫秒）
    private static final int TICK_MS = 16; // 约 60FPS

    private final JLabel timeLabel;
    private final JLabel stateLabel;

    private final Random random = new Random();

    private final Object lock = new Object();
    private List<Ball> balls = new ArrayList<>();

    private volatile boolean running = false;
    private volatile boolean gameOver = false;

    private volatile int mouseX = 50;
    private volatile int mouseY = 50;

    private Instant startTime;

    // 线程池：用一个后台线程跑游戏循环
    private ExecutorService executor;
    private Future<?> loopFuture;

    public GamePanel(JLabel timeLabel, JLabel stateLabel) {
        this.timeLabel = timeLabel;
        this.stateLabel = stateLabel;

        setBackground(Color.WHITE);
        setFocusable(true);

        // 将鼠标显示成“方块”：用自定义光标（黑方块）
        setCursor(createSquareCursor());

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                mouseMoved(e);
            }
        });

        // 方案A：鼠标离开游戏区域（面板）才算“碰到窗口四周/出界”，直接结束
        addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
                if (!gameOver && running) {
                    endGame("鼠标离开游戏区域（碰到窗口四周）");
                }
            }
        });
    }

    /** 开始/重开游戏 */
    public void startNewGame(int n) {
        stopLoopIfNeeded();

        // 初始化球
        List<Ball> newBalls = new ArrayList<>(n);
        int w = Math.max(getWidth(), 800);
        int h = Math.max(getHeight(), 500);

        for (int i = 0; i < n; i++) {
            int r = 8 + random.nextInt(10); // 半径 8~17
            double x = r + random.nextInt(Math.max(1, w - 2 * r));
            double y = r + random.nextInt(Math.max(1, h - 2 * r));

            // 速度：随机大小 + 随机方向
            double speed = 1.5 + random.nextDouble() * 4.5; // 1.5~6.0
            double angle = random.nextDouble() * Math.PI * 2.0;
            double vx = Math.cos(angle) * speed;
            double vy = Math.sin(angle) * speed;

            Color color = new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256));
            newBalls.add(new Ball(x, y, vx, vy, r, color));
        }

        synchronized (lock) {
            balls = newBalls;
        }

        // 初始化状态
        mouseX = w / 2;
        mouseY = h / 2;
        startTime = Instant.now();
        running = true;
        gameOver = false;
        stateLabel.setText("状态：进行中");

        // 启动循环线程
        executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "game-loop");
            t.setDaemon(true);
            return t;
        });

        loopFuture = executor.submit(new GameLoop());
    }

    /** 游戏循环 Runnable */
    private class GameLoop implements Runnable {
        @Override
        public void run() {
            long last = System.nanoTime();

            while (running && !Thread.currentThread().isInterrupted()) {
                long now = System.nanoTime();
                double dt = (now - last) / 1_000_000_000.0;
                last = now;

                updatePhysics(dt);
                checkCollisionAndEndIfNeeded();

                SwingUtilities.invokeLater(() -> {
                    if (startTime != null && !gameOver) {
                        double sec = Duration.between(startTime, Instant.now()).toMillis() / 1000.0;
                        timeLabel.setText(String.format("时间：%.1f s", sec));
                    }
                    repaint();
                });

                try {
                    Thread.sleep(TICK_MS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    /** 更新小球位置并处理“碰边反弹” */
    private void updatePhysics(double dt) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        synchronized (lock) {
            for (Ball b : balls) {
                b.x += b.vx;
                b.y += b.vy;

                // 左右边界：反弹只改方向（vx取反），速度大小不变
                if (b.x - b.r <= 0) {
                    b.x = b.r;
                    b.vx = -b.vx;
                } else if (b.x + b.r >= w) {
                    b.x = w - b.r;
                    b.vx = -b.vx;
                }

                // 上下边界：vy取反
                if (b.y - b.r <= 0) {
                    b.y = b.r;
                    b.vy = -b.vy;
                } else if (b.y + b.r >= h) {
                    b.y = h - b.r;
                    b.vy = -b.vy;
                }
            }
        }
    }

    /** 碰撞检测：鼠标方块 vs 任一小球（边界出界在 mouseExited 已处理） */
    private void checkCollisionAndEndIfNeeded() {
        if (gameOver) return;

        // 鼠标方块区域（左上角定位）
        int mx = mouseX - MOUSE_BOX / 2;
        int my = mouseY - MOUSE_BOX / 2;
        Rectangle mouseRect = new Rectangle(mx, my, MOUSE_BOX, MOUSE_BOX);

        // 只检测：碰到任意小球
        synchronized (lock) {
            for (Ball b : balls) {
                if (rectCircleIntersect(mouseRect, b.x, b.y, b.r)) {
                    endGame("碰到小球");
                    return;
                }
            }
        }
    }

    /** 结束游戏并弹窗显示坚持时间 */
    private void endGame(String reason) {
        gameOver = true;
        running = false;

        double sec = 0.0;
        if (startTime != null) {
            sec = Duration.between(startTime, Instant.now()).toMillis() / 1000.0;
        }
        double finalSec = sec;

        SwingUtilities.invokeLater(() -> {
            stateLabel.setText("状态：结束（" + reason + "）");
            timeLabel.setText(String.format("时间：%.1f s", finalSec));
            JOptionPane.showMessageDialog(this,
                    String.format("游戏结束：%s\n你坚持了：%.1f 秒", reason, finalSec),
                    "Game Over",
                    JOptionPane.INFORMATION_MESSAGE);
            repaint();
        });

        stopLoopIfNeeded();
    }

    /** 安全停止线程池 */
    private void stopLoopIfNeeded() {
        running = false;

        if (loopFuture != null) {
            loopFuture.cancel(true);
            loopFuture = null;
        }
        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }
    }

    /** 方块-圆相交判断：把圆心 clamp 到矩形内，计算距离 */
    private boolean rectCircleIntersect(Rectangle rect, double cx, double cy, double r) {
        double closestX = clamp(cx, rect.x, rect.x + rect.width);
        double closestY = clamp(cy, rect.y, rect.y + rect.height);
        double dx = cx - closestX;
        double dy = cy - closestY;
        return (dx * dx + dy * dy) <= (r * r);
    }

    private double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    /** 自定义方块光标（让鼠标看起来是方块） */
    private Cursor createSquareCursor() {
        int size = 16;
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, size, size);
        g.dispose();

        // 热点设为中心
        return Toolkit.getDefaultToolkit().createCustomCursor(img, new Point(size / 2, size / 2), "square");
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();

        // 画球
        synchronized (lock) {
            for (Ball b : balls) {
                g2.setColor(b.color);
                int x = (int) Math.round(b.x - b.r);
                int y = (int) Math.round(b.y - b.r);
                g2.fillOval(x, y, b.r * 2, b.r * 2);
            }
        }

        // 画鼠标方块（可视化）
        if (running || gameOver) {
            int mx = mouseX - MOUSE_BOX / 2;
            int my = mouseY - MOUSE_BOX / 2;
            g2.setColor(new Color(0, 0, 0, 90));
            g2.fillRect(mx, my, MOUSE_BOX, MOUSE_BOX);
        }

        // Game over 提示
        if (gameOver) {
            int w = getWidth();
            int h = getHeight();
            g2.setFont(g2.getFont().deriveFont(Font.BOLD, 42f));
            g2.setColor(new Color(0, 0, 0, 160));
            String s = "GAME OVER";
            FontMetrics fm = g2.getFontMetrics();
            int sw = fm.stringWidth(s);
            g2.drawString(s, (w - sw) / 2, h / 2);
        }

        g2.dispose();
    }
}